import React from 'react';

import Subjects from '../components/content/Subjects';
import Information from '../components/content/Information';
import Navigation from '../components/content/Navigation';

export default class Content extends React.Component {
  render() {
    return (
      <div id='content'>
        <Subjects />
        <Information />
        <Navigation />
      </div>
    );
  }
}
