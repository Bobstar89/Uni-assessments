import React from 'react';

//import Header from '../components/layout/Header';
// import Navigation from '../components/layout/Navigation';
import QuizGUI from '../components/quiz/QuizGUI';
//import Footer from '../components/layout/Footer';

export default class Quiz extends React.Component {
  render() {
    return (
      <QuizGUI />
    );
  }
}
