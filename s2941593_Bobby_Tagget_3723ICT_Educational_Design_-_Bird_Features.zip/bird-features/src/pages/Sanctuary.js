import React from 'react';

export default class Features extends React.Component {
  render() {
    return (
      <h1>To be implemented</h1>
    );
  }
}
