import React from 'react';

export default class Subjects extends React.Component {
  render() {
    return (
      <div className='subjects'>
        <a href='#' className='button'> Bird Anatomy </a>
        <a href='#' className='button'> World of Birds</a>
        <a href='#' className='button'> Eating Habits </a>
        <a href='#' className='button'> Taking Flight </a>
        <a href='#' className='button'> Predator and Prey</a>
      </div>
    );
  }
}
