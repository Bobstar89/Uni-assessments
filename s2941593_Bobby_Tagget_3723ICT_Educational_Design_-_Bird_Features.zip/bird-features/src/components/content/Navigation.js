import React from 'react';

export default class Navigation extends React.Component {
  render() {
    return (
      <div id='navigation'>
        <a href='#'>Previous</a>
        <a href='#'>Next</a>
        <a href='#'>Notebook</a>
      </div>
    );
  }
}
