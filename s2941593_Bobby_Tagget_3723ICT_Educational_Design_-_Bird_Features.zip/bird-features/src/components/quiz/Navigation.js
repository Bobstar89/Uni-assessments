import React from 'react';

export default class Navigation extends React.Component {
  render() {
    return (
      <div id='nav'>
        <a className='buttons' href='#'>Learn</a>
        <a className='buttons' href='#'>Notebook</a>
      </div>
    );
  }
}
