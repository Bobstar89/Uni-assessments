import React, { Component } from 'react';
import logo from './images/logo.png';

export default class Header extends Component {
  render() {
    return (
      <header>
        <img id='logo' src={logo} />
      </header>
    );
  }
}
