s2941593 Bobby Tagget presents Bird Features and their Environment

Based on Topic 3 - Bird Features of 3723ICT Educational Design's main assessment

Website address:   http://bird-features.netlify.com

Features: Basic Splash visuals
          Notebook visuals
          Quiz visuals
          Main learning content visuals

Instructions

  * The user is first shown the splash page, the intention of the splash page
    is allow students to view notes they have written about birds on display
    via clicking a particular bird
  * After exploring the splash page users may jump into the quiz screen or
    view the learning content screen
  * The Notebook will give the user a place to write their own notes regarding
    the content. Each page relating to the learning content will be titled to
    reflect the content sections.
  * Check boxes are the only functioning element of the Quiz page

Other

  * The project may be build from the source via the bird-features directory
    using the node package manager and running "npm run serve"
